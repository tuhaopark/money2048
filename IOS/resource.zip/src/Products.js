//================================================
//
//================================================
var Products = function(){
    cc.log("Products Func");
};

//================================================
//
//================================================
Products.prototype.onBack = function() {
    cc.log("go Back");
    cc.Director.getInstance().replaceScene(CCBMainMenu());
};

//================================================
//
//================================================
Products.prototype.onDLProduct1 = function() {
    show_product("http://itunes.apple.com/cn/app/id824713668?mt=8");
}
//================================================
//
//================================================
var CCBProducts = function () {
    cc.log("CCBProducts");
    var scene = cc.Scene.create();
    switch(language)
    {
        case 0:
            node = cc.BuilderReader.load("ccbi/Products.ccbi");
            break;
        case 12:
            node = cc.BuilderReader.load("ccbi/Products.ccbi");
            break;
        case 13:
            node = cc.BuilderReader.load("ccbi/Products.ccbi");
            break;
        default:
            node = cc.BuilderReader.load("ccbi/Products.ccbi");
            break;
            
    }
    
//    node = cc.BuilderReader.load("ccbi/Products.ccbi");
    
    scene.addChild(node);
    scene.setPosition(cc.p(0, 0));
    
    return scene;
};