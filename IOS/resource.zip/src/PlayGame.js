SCORES = [0, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192];
spendTime = 0;
highspendTime = 0;
READY = 0;
START = 1;
OVER = 2;
PAUSE = 3;
Timer = 20;
Timeremind = 0;
//================================================
//
//================================================
var GameScene = function(){
    cc.log("GameScene");
    this.MyBestScore = this.MyBestScore || {};
    this.CurScore = this.CurScore || {};
    this.GameTime = this.GameTime || {};
    this.Max = this.Max || {};
    this.Round = this.Round || {};
    this.TimeRemind = this.TimeRemind || {};
    this.GamePlayLayer = this.GamePlayLayer || {};
    this.GameOverLayer = this.GameOverLayer || {};
    this.ShopLayer = this.ShopLayer || {};
    this.SoundButton = this.SoundButton || {};
    this.num_bg = this.num_bg || {};

    this.Over_Score = this.Over_Score || {};
    this.Over_Time = this.Over_Time || {};
    this.Over_High = this.Over_High || {};
    this.Over_Round = this.Over_Round || {};
    this.Time_30 = this.Time_30 || {};
    
    this.numberArray = [0, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192];
    this.cellPosX = [152, 264, 376, 488];
    this.cellPosY = [496, 384, 272, 160];
    this.isMarge = 0;
    this.isMove = 0;
    this.totalScore = 0;
    this.roundcnt = 0;
    this.noMoreMove = 0;
    this.movelist = [];
    
    this.cellSpeed = 0.1;
    this.HighNum = 0;
    this.gameMode = READY;
    
    this.power = 0; //体力
    this.diamond = 0; //    钻石
    
    this.purchastype = -1;

};

//================================================
//
//================================================
GameScene.prototype.onDidLoadFromCCB = function () {
    if (sys.platform == 'browser') {
        this.onEnter();
    }
    else {
        this.rootNode.onEnter = function () {
            this.controller.onEnter();
        };
    }
    this.rootNode.schedule(function (dt) {
        this.controller.onUpdate(dt);
    });
    
    
    this.rootNode.onTouchesBegan = function (touches, event) {
        this.controller.onTouchesBegan(touches, event);
        return true;
    };
    
    this.rootNode.onTouchesMoved = function (touches, event) {
        this.controller.onTouchesMoved(touches, event);
        return true;
    };
    this.rootNode.onTouchesEnded = function (touches, event) {
        this.controller.onTouchesEnded(touches, event);
        return true;
    };
    
    this.rootNode.setTouchEnabled(true);
    if (soundOn)
    {
        audioEngine.playMusic(s_BGM, true);
        this.SoundButton.unselected();
    } else
    {
        this.SoundButton.selected();
    }
    

    this.iAP = MyBinding.IOSiAP();
    this.idarray = new Array();
    this.idarray[0] = "com.tuhaopark.money2048.6d";
    this.idarray[1] = "com.tuhaopark.money2048.36d";
    this.idarray[2] = "com.tuhaopark.money2048.80d";
    this.idarray[3] = "com.tuhaopark.money2048.150d";

    this.iAP.requestProducts(this.idarray);
    this.requestFinish = 0;
    this.iAP.onRequestProductsFinish = function () {
        cc.log("==requestFinish");
        this.requestFinish = 1;
//        var product = this.iAP.iOSProductByIdentifier(this.idarray[1]);
//        cc.log(product.productIdentifier + "\n"
//                                    + product.localizedTitle + "\n"
//                                    + product.localizedDescription + "\n"
//                                    + product.localizedPrice + "\n"
//                                    + "isValid:" + product.isValid);

    }.bind(this);
    
    this.iAP.onRequestProductsError = function (code) {
        cc.log("==requestError:" + code);
    }.bind(this);
    
    this.iAP.onPaymentEvent = function (identifier, eventCode, quantity) {
        var eventString = "";
        switch (eventCode) {
            case 0:
                eventString = "purchasing";
                break;
            case 1:
            {
//                eventString = "purchased get 100 coins";
                var xhr = new XMLHttpRequest();
                var gamethis = this;
                xhr.onreadystatechange = function()
                {
                    if (xhr.readyState==4)
                    {
                        if (xhr.status==200)
                        {
                            
                            var response = JSON.parse(xhr.responseText);
                            this.power = response.power;
                            this.power_no.setString(gamethis.power);
                            this.diamond = response.game_diamond;
                            this.daimond_no.setString(gamethis.diamond);
                            this.ShopLayer.setVisible(false);
                            this.Message_MenuBTN.setTouchEnabled(true);
                            this.CheckPower();
                            
                        }
                    }
                }.bind(this);
                var urlcmd = "http://60.12.206.137/money2048/purchas.php?player_id="+get_tuhaoid()+"&type="+this.purchastype;
//                var urlcmd = "http://192.168.0.100/cdplatform/money2048/purchas.php?player_id="+get_tuhaoid()+"&type="+this.purchastype;
                cc.log(urlcmd);
                xhr.open("GET", urlcmd, true);
                xhr.send(null);

            }
                break;
            case 2:
                eventString = "purchase Failed";
                break;
            case 3:
                eventString = "purchase restored";
                break;
            case 4:
                eventString = "purchase removed";
                break;
        }
        cc.log(eventString);
    }.bind(this);
    this.ShopLayer.setVisible(false);
};

//================================================
//================================================
GameScene.prototype.onAddPower = function()
{
    
};
//================================================
//================================================
GameScene.prototype.onSpendDiamond = function()
{
    
};
//================================================
//================================================
GameScene.prototype.onStartGame = function()
{
    this.MessageLayer.setVisible(false);
    this.num_bg.setVisible(true);
    this.Time_30.setVisible(true);
    
    var random1 = getRandom(4);
    var random2 = getRandom(4);
    while (random1 == random2) {
        random2 = getRandom(4);
    }
    
    var random11 = getRandom(4);
    var random22 = getRandom(4);
    
    this.getCellpostion(3,3);
    
    this.tables = new Array(4);
    for (var x = 0; x < 4; x++) {
        var sprites = new Array(4);
        for (var y = 0; y < 4; y++) {
            if (x == random1 && y == random11) {
                sprites[y] = this.newNumber(x, y, 1);
            } else if (x == random2 && y == random22) {
                sprites[y] = this.newNumber(x, y, 1);
            }
            else {
                sprites[y] = this.newNumber(x, y, 0);
            }
        }
        this.tables[x] = sprites;
    }
    this.resetTimer();
    this.rootNode.schedule(this.OneSec,1);
//    this.gameMode = START;

    var xhr = new XMLHttpRequest();
    var gamethis = this;
    xhr.onreadystatechange = function()
    {
        if (xhr.readyState==4)
        {
            if (xhr.status==200)
            {
                
                var response = JSON.parse(xhr.responseText);
                gamethis.power = response.power;
                gamethis.power_no.setString(gamethis.power);
                gamethis.diamond = response.game_diamond;
                gamethis.daimond_no.setString(gamethis.diamond);
                gamethis.resetTimer();
                gamethis.gameMode = START;

            }
        }
    }
    var urlcmd = "http://60.12.206.137/money2048/startgame.php?player_id="+get_tuhaoid();
//    var urlcmd = "http://192.168.0.100/cdplatform/money2048/startgame.php?player_id="+get_tuhaoid();
    xhr.open("GET", urlcmd, true);
    xhr.send(null);
    
};
//================================================
//================================================
GameScene.prototype.onGoShop = function()
{
    if (this.requestFinish == 1)
    {
        this.ShopBG.setVisible(true);
        this.WaitMsg.setVisible(false);  //等待Itune回复，显示等待

        this.Message_MenuBTN.setTouchEnabled(false);    //关闭message layer 上的按钮
        this.ShopLayer.setVisible(true);
    }
    

};
//================================================
//================================================
GameScene.prototype.onRefill = function()
{
    var xhr = new XMLHttpRequest();
    var gamethis = this;
    xhr.onreadystatechange = function()
    {
        if (xhr.readyState==4)
        {
            if (xhr.status==200)
            {
                var response = JSON.parse(xhr.responseText);
                gamethis.power = response.power;
                gamethis.power_no.setString(gamethis.power);
                gamethis.diamond = response.game_diamond;
                gamethis.daimond_no.setString(gamethis.diamond);
                gamethis.CheckPower();
            }
        }
    }
    var urlcmd = "http://60.12.206.137/money2048/refill.php?player_id="+get_tuhaoid();
//    var urlcmd = "http://192.168.0.100/cdplatform/money2048/refill.php?player_id="+get_tuhaoid();
    xhr.open("GET", urlcmd, true);
    xhr.send(null);

};
//================================================
//================================================
GameScene.prototype.onCloseShop = function()
{
    this.Message_MenuBTN.setTouchEnabled(true);
    this.ShopLayer.setVisible(false);
};
//================================================
//================================================
GameScene.prototype.onPay = function(sender)
{
    cc.log("tag:"+sender.getTag());
    this.purchastype = -1;
    switch (sender.getTag())
    {
        case 6:
            this.purchastype = 0;
            var product = this.iAP.iOSProductByIdentifier(this.idarray[0]);
            this.iAP.paymentWithProduct(product, 1);
            break;
        case 30:
            this.purchastype = 1;
            var product = this.iAP.iOSProductByIdentifier(this.idarray[1]);
            this.iAP.paymentWithProduct(product, 1);
            break;
        case 68:
            this.purchastype = 2;
            var product = this.iAP.iOSProductByIdentifier(this.idarray[2]);
            this.iAP.paymentWithProduct(product, 1);
            break;
        case 128:
            this.purchastype = 3;
            var product = this.iAP.iOSProductByIdentifier(this.idarray[3]);
            this.iAP.paymentWithProduct(product, 1);
            break;
    }
    this.ShopBG.setVisible(false);
    this.WaitMsg.setVisible(true);  //等待Itune回复，显示等待
};
//================================================
//================================================
GameScene.prototype.onBack = function()
{
    cc.log("onBack");
    cc.Director.getInstance().replaceScene(CCBMainMenu());
};
//================================================
//================================================
GameScene.prototype.onDownload = function() {
    show_product("http://itunes.apple.com/cn/app/id824713668?mt=8");
}
//================================================
//================================================
GameScene.prototype.onUpdate = function (dt) {
    if (this.gameMode == START)
    {
        this.GameTime.setString(getTotalTime(spendTime));
        this.TimeRemind.setString(Timeremind);
        if (Timeremind <=0)
            this.GameOver();
    }
};

//================================================
//================================================
GameScene.prototype.OneSec = function() {
    {
        spendTime++;
        Timeremind--;
    }
};

//================================================
//
//================================================
GameScene.prototype.getCellpostion = function (x, y) {
    var px = this.cellPosX[x];
    var py = this.cellPosY[y];
    
    return cc.p(px, py);
}
//================================================
// 从服务器取得物件数量
//================================================
GameScene.prototype.getItems = function () {
    var xhr = new XMLHttpRequest();
    var gamethis = this;
    xhr.onreadystatechange = function()
    {
        if (xhr.readyState==4)
        {
            if (xhr.status==200)
            {
                var response = JSON.parse(xhr.responseText);
                gamethis.power = response.power;
                gamethis.power_no.setString(gamethis.power);
                gamethis.diamond = response.game_diamond;
                gamethis.daimond_no.setString(gamethis.diamond);
                gamethis.CheckPower();
            }
        }
    }
    var urlcmd = "http://60.12.206.137/money2048/getitems.php?player_id="+get_tuhaoid();
//    var urlcmd = "http://192.168.0.100/cdplatform/money2048/getitems.php?player_id="+get_tuhaoid();
    xhr.open("GET", urlcmd, true);
    xhr.send(null);
};
//================================================
//
//================================================
GameScene.prototype.onEnter = function () {
    cc.log("GameScene OnEnter");

    this.rootNode.setTouchEnabled(true);
    this.GameOverLayer.setVisible(false);
    this.Max.setString("0");
    this.Round.setString("0");
    this.GameTime.setString("00:00:00");
    
    this.isMarge = 0;
    this.isMove = 0;
    this.roundcnt = 0;
    this.totalScore = 0;
    this.noMoreMove = 0;
    this.movelist = [];
    this.HighNum = 0;
    spendTime = 0;
    
    this.Over_Score.setString("0000");
    this.Over_Time.setString("00:00:00");
    this.Over_High.setString("0000");
    this.Over_Round.setString("00");
    
    this.initData();

    this.getItems();
};
//================================================
//
//================================================
GameScene.prototype.CheckPower = function() {
    if (this.power >0)
    {
        
        this.RefillMsg.setVisible(false);
        this.NoPowerMsg.setVisible(false);
        this.Readme.setVisible(true);
        
        this.StartGame_Btn.setVisible(true);
        this.GoShop_Btn.setVisible(false);
        this.Refill_Btn.setVisible(false);
    }
    else if (this.diamond >= 5)
    {
        this.RefillMsg.setVisible(true);
        this.GoShop_Btn.setVisible(true);
        this.GoShop_Btn.setEnabled(true);
        this.Refill_Btn.setVisible(true);
        this.Refill_Btn.setEnabled(true);
    }
    else
    {
        this.NoPowerMsg.setVisible(true);
        this.GoShop_Btn.setVisible(true);
        this.Refill_Btn.setVisible(true);
        this.Refill_Btn.setEnabled(false);
    }
};
//================================================
// 初始化本地保存数据
//================================================
GameScene.prototype.initData = function() {

    this.MyBestScore.setString(best);
    this.Max.setString(maxnum);
    

};

//================================================
//
//================================================
GameScene.prototype.onSound = function (sender) {
    
    if (soundOn)
    {
        sys.localStorage.setItem('Sound', 0);   //声音是否开启
        soundOn = 0;
        audioEngine.stopMusic();
        sender.selected();
    }
    else
    {
        sys.localStorage.setItem('Sound', 1);   //声音是否开启
        soundOn = 1;
        audioEngine.playMusic(s_BGM, true);
        sender.unselected();
    }
}
//================================================
// 产生新的cell
//================================================
GameScene.prototype.newNumber = function (x, y, num) {
    
    var cell = new Object();
    
    if (num > 0)
    {
//        cc.log("x:"+x+" y:"+y+" tag:"+(100+y*4+x));
       cell.sprite = cc.MySprite.create(this.GamePlayLayer, "num_2.png", this.getCellpostion(x, y), 1, 100+y*4+x);
    }
    cell.data = {col: x, row: y, number: num, tag: 100+y*4+x, toX:0 , toY:0};
    return cell;
};
//================================================
//
//================================================
GameScene.prototype.CheckNoMoreMove = function() {
    for (var y = 0; y < 4; y++)
    {
        for (var x = 0; x < 4; x++)
        {
            var cell = this.tables[x][y];
            
            
            if (x < 3)
            {
                var nextCell = this.tables[x+1][y];
                if (cell.data.number == nextCell.data.number) {
                    return 0;
                }
                if (y < 3)
                {
                    var nextYcell = this.tables[x][y+1];
                    if (cell.data.number == nextYcell.data.number) {
                        return 0;
                    }
                }
            }
            else {
                if (y < 3) {
                    var nextYcell = this.tables[x][y+1];
                    if (cell.data.number == nextYcell.data.number) {
                        return 0;
                    }
                }

            }
        }
        
    }
    return 1;
};
//================================================
//
//================================================
GameScene.prototype.resetTimer = function () {
    Timeremind = Timer;
    this.TimeRemind.setString(Timer);
//    this.left.setPercentage(0);
//    cc.log("setPercentage");
//cc.log("percent:"+this.left.getPercentage());

}
//================================================
// 游戏结束
//================================================
GameScene.prototype.GameOver = function () {
    if (this.gameMode != OVER)
    {
        this.gameMode = OVER;
        if (soundOn)
            audioEngine.playEffect(s_gameover);
        
        this.rootNode.unschedule(this.OneSec);
        this.rootNode.stopAllActions();
        
        if (best < this.totalScore)
        {
            sys.localStorage.setItem('bestScore',this.totalScore);
            if (soundOn)
                audioEngine.playEffect(s_best);
            
        }
        if (maxnum < this.numberArray[this.HighNum])
        {
            sys.localStorage.setItem('Maxnum',this.numberArray[this.HighNum]);
            
        }
        
        this.Over_Score.setString(this.totalScore);
        this.Over_Time.setString(getTotalTime(highspendTime));
        this.Over_High.setString(this.numberArray[this.HighNum]);
        this.Over_Round.setString(this.roundcnt);
        
        
        this.rootNode.setTouchEnabled(false);
        this.GameOverLayer.setVisible(true);
        audioEngine.stopMusic();
        
        var user_id = get_tuhaoid();
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function()
        {
            if (xhr.readyState==4)
            {// 4 = "loaded"
                if (xhr.status==200)
                {// 200 = "OK"
//                    var response = JSON.parse(xhr.responseText);
//                    cc.log(response.baseinfo.nickname);
                    //                theHelloLabel.setString(response.data);
                } else {
                    cc.log("Problem retrieving JSON data:" + xhr.statusText);
                    cc.log("Error=>"+xhr.responseText);
                }
            }
        };
//        xmlhttp.setRequestHeader("Content-Length",arg.lenght);
//        xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");  //用POST的时候一定要有这句
        //发起一个GET请求
        cc.log(urlcmd);
        var urlcmd = "http://60.12.206.137/money2048/saverankmoney2048.php?userid="+user_id+"&score="+this.totalScore+"&high="+this.numberArray[this.HighNum]+"&round="+this.roundcnt+"&spendtime="+highspendTime;
//        var urlcmd = "http://192.168.0.100/cdplatform/money2048/saverankmoney2048.php?userid="+user_id+"&score="+this.totalScore+"&high="+this.numberArray[this.HighNum]+"&round="+this.roundcnt+"&spendtime="+highspendTime;
        cc.log(urlcmd);
        xhr.open("GET", urlcmd);
        xhr.send(null);
    }
}
//================================================
//
//================================================
GameScene.prototype.DoubleCheck = function () {

    for (var y = 0; y < 4; y++)
    {
        for (var x = 0; x < 4; x++)
        {
            var cell = this.tables[x][y];
            var cellNumber = cell.data.number;
            if (cellNumber == 0)
            {
                return;
            }
        }
    }
    if (this.CheckNoMoreMove() == 1) {
        this.GameOver();
    }

}
//================================================
//
//================================================
GameScene.prototype.refreshNumber = function () {
    var emptyCellList = [];

    for (var i = 100; i < 116; i++)
    {
        this.GamePlayLayer.removeChildByTag(i);
    }

    for (var y = 0; y < 4; y++)
    {
        var numbers = " ";
        for (var x = 0; x < 4; x++)
        {
            var cell = this.tables[x][y];
            
            var cellNumber = cell.data.number;
            if (cellNumber != 0)
            {
                var realnum = this.numberArray[cellNumber];
                cell.sprite = cc.MySprite.create(this.GamePlayLayer, "num_"+realnum+".png", this.getCellpostion(x, y), 1, 100+y*4+x);
                
                if (cellNumber == (this.numberArray.length - 1)) {
                    cc.log("success 2048");
                }
            }
            else
            {
                emptyCellList.push(cell);
            }
            numbers += "  " +this.numberArray[cellNumber];
        }
//        cc.log("numbers==" + numbers);
    }
    
    
    //score
    this.CurScore.setString(this.totalScore);
    
    if (emptyCellList.length < 1)
    {
        //已经没有任何空白
        if (this.CheckNoMoreMove() == 1) {
//            cc.log("结束");
            this.GameOver();
        }
    } else {
        if ((this.isMove == 1) || (this.isMarge == 1))
        {
            this.resetTimer();

            this.roundcnt++;
            this.Round.setString(this.roundcnt);
            //产生新的cell
            var randomCell = emptyCellList[getRandom(emptyCellList.length)];
            randomCell.data.number = 1;
            var x = randomCell.data.col;
            var y = randomCell.data.row;
            randomCell.sprite = cc.MySprite.create(this.GamePlayLayer, "num_2.png", this.getCellpostion(x, y), 1, 100+y*4+x);
            randomCell.sprite.runAction(cc.Sequence.create(cc.ScaleTo.create(0, 0.7), cc.ScaleTo.create(0.5, 1)));
            this.DoubleCheck();
        }
        
    }
    this.isMarge = 0;
    this.isMove = 0;
    this.movelist = [];

};

//================================================
// 往左移
//================================================
GameScene.prototype.leftCombineNumber = function () {
    for (var j = 0; j < 4; j++) {
        for (var i = 0; i < 4; i++) {
            var cell = this.tables[i][j];
            if (cell.data.number != 0) {
                var k = i + 1;
                while (k < 4) {
                    var nextCell = this.tables[k][j];
                    if (nextCell.data.number != 0) {
                        if (cell.data.number == nextCell.data.number) {
                            if (soundOn)
                                audioEngine.playEffect(s_move);
                            this.isMarge = 1;
                            cell.data.number += 1;
                            nextCell.data.number = 0;
                            if (this.HighNum < cell.data.number)
                            {
                                this.HighNum = cell.data.number;
                                highspendTime = spendTime;
                            }
                            this.totalScore += SCORES[cell.data.number];
                            nextCell.data.toX = i;
                            nextCell.data.toY = j;
                            var px = this.cellPosX[nextCell.data.toX];
                            var py = this.cellPosY[nextCell.data.toY];
                            var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                            nextCell.sprite.runAction(actionTo);
                        }
                        k = 4;
                        break;
                    }
                    k++;
                }
            }
        }
    }
    
    for (j = 0; j < 4; j++) {
        for (i = 0; i < 4; i++) {
            cell = this.tables[i][j];
            if (cell.data.number == 0) {
                k = i + 1;
                while (k < 4) {
                    nextCell = this.tables[k][j];
                    if (nextCell.data.number != 0) {
                        if (soundOn)
                            audioEngine.playEffect(s_move);

                        this.isMove = 1;
                        nextCell.data.toX = i;
                        nextCell.data.toY = j;
                        
                        var px = this.cellPosX[nextCell.data.toX];
                        var py = this.cellPosY[nextCell.data.toY];
                        var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                        nextCell.sprite.runAction(actionTo);
                        
                        cell.data.number = nextCell.data.number;
                        nextCell.data.number = 0;
                        k = 4;
                    }
                    k++;
                }
            }
        }
    }
    this.GamePlayLayer.runAction(cc.Sequence.create(cc.DelayTime.create(this.cellSpeed), cc.CallFunc.create(this.refreshNumber, this)));
};


//================================================
//
//================================================
GameScene.prototype.rightCombineNumber = function () {
    for (var j = 0; j < 4; j++) {
        for (var i = 3; i >= 0; i--) {
            var cell = this.tables[i][j];
            if (cell.data.number != 0) {
                var k = i - 1;
                while (k >= 0) {
                    var nextCell = this.tables[k][j];
                    if (nextCell.data.number != 0) {
                        if (cell.data.number == nextCell.data.number) {
                            if (soundOn)
                                audioEngine.playEffect(s_move);

                            this.isMarge = 1;
                            cell.data.number += 1;
                            nextCell.data.number = 0;
                            if (this.HighNum < cell.data.number)
                            {
                                this.HighNum = cell.data.number;
                                highspendTime = spendTime;
                            }

                            this.totalScore += SCORES[cell.data.number];
                            
                            nextCell.data.toX = i;
                            nextCell.data.toY = j;
                            var px = this.cellPosX[nextCell.data.toX];
                            var py = this.cellPosY[nextCell.data.toY];
                            var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                            nextCell.sprite.runAction(actionTo);
                            
                        }
                        k = -1;
                        break;
                    }
                    k--;
                }
            }
        }
    }
    
    for (j = 0; j < 4; j++) {
        for (i = 3; i >= 0; i--) {
            cell = this.tables[i][j];
            if (cell.data.number == 0) {
                k = i - 1;
                while (k >= 0) {
                    nextCell = this.tables[k][j];
                    if (nextCell.data.number != 0) {
                        if (soundOn)
                            audioEngine.playEffect(s_move);

                        this.isMove = 1;
                        
                        nextCell.data.toX = i;
                        nextCell.data.toY = j;
                        
                        var px = this.cellPosX[nextCell.data.toX];
                        var py = this.cellPosY[nextCell.data.toY];
                        var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                        nextCell.sprite.runAction(actionTo);
                        
                        
                        cell.data.number = nextCell.data.number;
                        nextCell.data.number = 0;
                        k = -1;
                    }
                    k--;
                }
            }
        }
    }
    
    this.GamePlayLayer.runAction(cc.Sequence.create(cc.DelayTime.create(this.cellSpeed), cc.CallFunc.create(this.refreshNumber, this)));
};

//================================================
//
//================================================
GameScene.prototype.downCombineNumber = function () {
    for (var i = 0; i < 4; i++) {
        for (var j = 0; j < 4; j++) {
            var cell = this.tables[i][j];
            if (cell.data.number != 0) {
                var k = j + 1;
                while (k < 4) {
                    var nextCell = this.tables[i][k];
                    if (nextCell.data.number != 0) {
                        if (cell.data.number == nextCell.data.number) {
                            if (soundOn)
                                audioEngine.playEffect(s_move);

                            this.isMarge = 1;
                            cell.data.number += 1;
                            nextCell.data.number = 0;
                            if (this.HighNum < cell.data.number)
                            {
                                this.HighNum = cell.data.number;
                                highspendTime = spendTime;
                            }

                            this.totalScore += SCORES[cell.data.number];
                            
                            nextCell.data.toX = i;
                            nextCell.data.toY = j;
                            var px = this.cellPosX[nextCell.data.toX];
                            var py = this.cellPosY[nextCell.data.toY];
                            var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                            nextCell.sprite.runAction(actionTo);
                            
                        }
                        k = 4;
                        break;
                    }
                    k++;
                }
            }
        }
    }
    
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++) {
            cell = this.tables[i][j];
            if (cell.data.number == 0) {
                k = j + 1;
                while (k < 4) {
                    nextCell = this.tables[i][k];
                    if (nextCell.data.number != 0) {
                        if (soundOn)
                            audioEngine.playEffect(s_move);

                        this.isMove = 1;
                        
                        nextCell.data.toX = i;
                        nextCell.data.toY = j;
                        
                        var px = this.cellPosX[nextCell.data.toX];
                        var py = this.cellPosY[nextCell.data.toY];
                        var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                        nextCell.sprite.runAction(actionTo);
                        
                        cell.data.number = nextCell.data.number;
                        nextCell.data.number = 0;
                        k = 4;
                    }
                    k++;
                }
            }
        }
    }
    
    this.GamePlayLayer.runAction(cc.Sequence.create(cc.DelayTime.create(this.cellSpeed), cc.CallFunc.create(this.refreshNumber, this)));
};

//================================================
//
//================================================
GameScene.prototype.upCombineNumber = function () {
    for (var i = 0; i < 4; i++) {
        for (var j = 3; j >= 0; j--) {
            var cell = this.tables[i][j];
            if (cell.data.number != 0) {
                var k = j - 1;
                while (k >= 0) {
                    var nextCell = this.tables[i][k];
                    if (nextCell.data.number != 0) {
                        if (cell.data.number == nextCell.data.number) {
                            if (soundOn)
                                audioEngine.playEffect(s_move);

                            this.isMarge = 1;
                            cell.data.number += 1;
                            nextCell.data.number = 0;
                            if (this.HighNum < cell.data.number)
                            {
                                this.HighNum = cell.data.number;
                                highspendTime = spendTime;
                            }

                            this.totalScore += SCORES[cell.data.number];

                            nextCell.data.toX = i;
                            nextCell.data.toY = j;
                            var px = this.cellPosX[nextCell.data.toX];
                            var py = this.cellPosY[nextCell.data.toY];
                            var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                            nextCell.sprite.runAction(actionTo);
                            
                        }
                        k = -1;
                        break;
                    }
                    k--;
                }
            }
        }
    }
    
    for (i = 0; i < 4; i++) {
        for (j = 3; j >= 0; j--) {
            cell = this.tables[i][j];
            if (cell.data.number == 0) {
                k = j - 1;
                while (k >= 0) {
                    nextCell = this.tables[i][k];
                    if (nextCell.data.number != 0) {
                        if (soundOn)
                            audioEngine.playEffect(s_move);

                        this.isMove = 1;
                        
                        nextCell.data.toX = i;
                        nextCell.data.toY = j;
                        
                        var px = this.cellPosX[nextCell.data.toX];
                        var py = this.cellPosY[nextCell.data.toY];
                        var actionTo = cc.MoveTo.create(this.cellSpeed, cc.p(px, py));
                        nextCell.sprite.runAction(actionTo);
                        
                        cell.data.number = nextCell.data.number;
                        nextCell.data.number = 0;
                        k = -1;
                    }
                    k--;
                }
            }
        }
    }
    
    this.GamePlayLayer.runAction(cc.Sequence.create(cc.DelayTime.create(this.cellSpeed), cc.CallFunc.create(this.refreshNumber, this)));
};
//================================================
//
//================================================
GameScene.prototype.onTouchesBegan = function (touches, event) {
    this.pBegan = touches[0].getLocation();
    
    //back
//    var backRect = cc.rectCreate(this.back.getPosition(), [50, 30]);
//    if (cc.rectContainsPoint(backRect, this.pBegan)) {
//        this.back.runAction(cc.Sequence.create(cc.ScaleTo.create(0.2, 1.1),
//                                               cc.CallFunc.create(function () {
//                                                                  cc.AudioEngine.getInstance().stopAllEffects();
//                                                                  cc.BuilderReader.runScene("", "LevelLayer");
//                                                                  })
//                                               ));
//    }
};

//================================================
//
//================================================
GameScene.prototype.onTouchesMoved = function (touches, event) {
};

//================================================
//
//================================================
GameScene.prototype.onTouchesEnded = function (touches, event) {
    this.pEnded = touches[0].getLocation();
    if (this.pBegan) {
        this.isMarge = 0;
        var ydist = Math.abs(this.pEnded.y - this.pBegan.y);
        var xdist = Math.abs(this.pEnded.x - this.pBegan.x);
        
        if (ydist > xdist)
        {
            cc.log("Up or Down");
            if (this.pEnded.y - this.pBegan.y > 50) {
                cc.log("Go Up");
                this.downCombineNumber();
            }
            
            else if (this.pEnded.y - this.pBegan.y < -50) {
                cc.log("Go Down");
                this.upCombineNumber();
            }
            
        }
        else
        {
            cc.log("Left or Right");
            if (this.pEnded.x - this.pBegan.x > 50) {
                cc.log("Go Right");
                this.rightCombineNumber();
            }
            
            else if (this.pEnded.x - this.pBegan.x < -50) {
                cc.log("Go Left");
                this.leftCombineNumber();
            }
            
        }
        
    }
};

//================================================
//
//================================================
var CCBPlayGame = function () {
    cc.log("CCBPlayGame");
    var scene = cc.Scene.create();
    cc.log("language:===>"+language);
    switch(language)
    {
//        case 0:
//            node = cc.BuilderReader.load("ccbi/GameScene_en.ccbi");
//            break;
//        case 12:
//            node = cc.BuilderReader.load("ccbi/GameScene.ccbi");
//            break;
//        case 13:
//            node = cc.BuilderReader.load("ccbi/GameScene_cht.ccbi");
//            break;
        default:
            node = cc.BuilderReader.load("ccbi/GameScene.ccbi");
            break;
            
    }
    
//    node = cc.BuilderReader.load(s_Gamescene);
    
    scene.addChild(node);
    scene.setPosition(cc.p(0, 0));
    
    return scene;
};