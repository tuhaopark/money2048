//===========================================================
//
//===========================================================
function getRandom(maxSize) {
    return Math.floor(Math.random() * maxSize) % maxSize;
}

function checkEMail()
{
//    var email = document.getElementById("txtEMail").value;
//    var re = /^[a-zA-Z0-9]([a-zA-Z0-9]*[-_.]?[a-zA-Z0-9]+)+@([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}$/;
//    if(email==null||email=="")
//    {
//        alert("EMail不能为空!");
//        return false;
//    }
//    if(!re.test(email))
//    {
//        alert("EMail格式不正确!");
//        return false;
//    }
//    return true;
}

//===========================================================
//
//===========================================================
function getTotalTime(time) {
    var iHour = Math.floor(time / 3600);
    var iMin  = Math.floor((time - iHour * 3600) / 60);
    var iSen  = Math.floor(time - iHour * 3600 - iMin * 60);
    var remainTime = getTimeFormat(iHour) + ":" + getTimeFormat(iMin) + ":" + getTimeFormat(iSen);
    return  remainTime;
    
}
//===========================================================
//
//===========================================================
//function open_appstore() {
//    //http://itunes.apple.com/cn/app/id425349261?mt=8
//    //https://itunes.apple.com/cn/app/tu-hao-le-yuan-ai-qing-pei-dui/id824713668?mt=8
//    window.location='http://itunes.apple.com/cn/app/id824713668?mt=8';
//}
//===========================================================
//
//===========================================================
getTimeFormat = function (time) {
    if (time <= 9) {
        return "0" + time;
    }
    else {
        return "" + time;
    }
};
//===========================================================
//
//===========================================================
cc.MySprite = {};
cc.MySprite.create = function (node, frameName, position, ZOrder, tag) {
    var sprite = cc.Sprite.createWithSpriteFrameName(frameName);
    sprite.setPosition(position);
    sprite.setZOrder(ZOrder);
    sprite.setAnchorPoint(cc.p(0.5, 0.5));
    sprite.setTag(tag);
    node.addChild(sprite);
    return sprite;
};

//===========================================================
//
//===========================================================
cc.getRandomFromMax = function (maxSize) {
    return Math.floor(Math.random() * maxSize) % maxSize;
};
