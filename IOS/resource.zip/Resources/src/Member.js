
//================================================
//
//================================================
var Member = function(){
    cc.log("member Func");
    this.Member_ID = this.Member_ID || {};
    this.NicknameLabel = this.NicknameLabel || {};
    this.MemberLayer = this.MemberLayer || {};
    this.testlayer = this.testlayer || {};
};

//Member.prototype.onEnter = function() {
//    cc.log("Member OnEnter");
//}
//Member.prototype.onTouchesBegan = function (touches, event) {
//    cc.log("Member touch test");
//    return true;
//};

//================================================
//
//================================================
Member.prototype.onDidLoadFromCCB = function () {
    this.Member_ID.setString(get_tuhaoid());
    
//    this.rootNode.onEnter = function () {
//        this.controller.onEnter();
//    };
//    this.rootNode.onTouchesBegan = function (touches, event) {
//        cc.log("root touch test");
//        this.controller.onTouchesBegan(touches, event);
//        return true;
//    };
//    this.rootNode.setTouchEnabled(true);
//    this.testlayer.onEnter = function () {
//        cc.log("test OnEnter");
//        this.testlayer.setTouchEnabled(true);
////        this.testlayer.setTouchMode(cc.TOUCH_ONE_BY_ONE);
//        this.testlayer.setTouchPriority(cc.MENU_HANDLER_PRIORITY + 1);
//        cc.registerTargetedDelegate(-129, true, this.testlayer);
//    }.bind(this);
//    this.testlayer.onTouchesBegan = function (touches, event) {
//        cc.log("touch test");
//        
//        return true;
//    };

    var xhr = new XMLHttpRequest();
//    var engine = this;
    xhr.onreadystatechange = function()
    {
        if (xhr.readyState==4)
        {// 4 = "loaded"
            if (xhr.status==200)
            {// 200 = "OK"
                cc.log(xhr.responseText);
                var response = JSON.parse(xhr.responseText);

                this.NicknameLabel.setString(response.baseinfo.nickname);
                var base = response["baseinfo"];
                this.nick = base["nickname"];
                this.password = base["password"];
                this.imnumber = base["QQnumber"];
                this.mobile = base["mobile"];
                this.email = base["email"];
                this._box1.setText(this.nick);
                this._box2.setText(this.mobile);
                this._box3.setText(this.email);
                this._box4.setText(this.imnumber);
                this.oldmobile = this.mobile;
                this.oldemail = this.email;
//                if (nick.length > 0)
//                    cc.log(nick.length);
                cc.log("read password:"+this.password.length);
                if (this.password != '')
                {
                    this.ModifyPassword_Btn.setVisible(true);
                    this.SetupPassword_Btn.setVisible(false);
                }
                else
                {
                    this.ModifyPassword_Btn.setVisible(false);
                    this.SetupPassword_Btn.setVisible(true);
                }
                cc.log("password："+this.password+"\n"+"QQ："+this.imnumber+"\n"+"mobile："+this.mobile+"\n"+"email："+this.email);
            } else {
                cc.log("Problem retrieving JSON data:" + xhr.statusText);
            }
        }
    }.bind(this);     //发起一个GET请求
    var urlcmd = "http://60.12.206.137/baseinfo.php?userid="+get_tuhaoid();
//    var urlcmd = "http://192.168.0.100/cdplatform/baseinfo.php?userid="+get_tuhaoid();
    xhr.open("GET", urlcmd);
    xhr.send(null);
    
    //Nickname
    this._box1 = cc.EditBox.create(cc.size(300, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box1.setText("");
    this._box1.setPosition(360, 450);
    this._box1.setFontColor(cc.c3b(251, 250, 0));
    this._box1.setDelegate(this);
    this._box1.setZOrder(0);
    this.MemberLayer.addChild(this._box1);

    //手机号
    this._box2 = cc.EditBox.create(cc.size(300, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box2.setText("");
    this._box2.setInputMode(cc.EDITBOX_INPUT_MODE_PHONENUMBER);
    this._box2.setPosition(360, 380);
    this._box2.setFontColor(cc.c3b(251, 250, 0));
    this._box2.setDelegate(this);
    this._box2.setZOrder(0);
    this.MemberLayer.addChild(this._box2);

    this._box3 = cc.EditBox.create(cc.size(300, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box3.setText("");
    this._box3.setInputMode(cc.EDITBOX_INPUT_MODE_EMAILADDR);
    this._box3.setPosition(360, 310);
    this._box3.setFontColor(cc.c3b(251, 250, 0));
    this._box3.setDelegate(this);
    this._box3.setZOrder(0);
    this.MemberLayer.addChild(this._box3);

    //QQ
    this._box4 = cc.EditBox.create(cc.size(300, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box4.setText("");
    this._box4.setInputMode(cc.EDITBOX_INPUT_MODE_PHONENUMBER);
    this._box4.setPosition(360, 240);
    this._box4.setFontColor(cc.c3b(251, 250, 0));
    this._box4.setDelegate(this);
    this._box4.setZOrder(0);
    this.MemberLayer.addChild(this._box4);
    
//    this._box1.setEnabled(false);
    this.check_m = 0;
    this.check_e = 0;
    this.oldmobile ="";
    this.oldemail ="";
    
    this.editBoxEditingDidBegin = function (editBox) {
        cc.log("editBox begin");
//        if (editBox == this._box2)
//            this.oldmobile = this._box2.getText();
//        if (editBox == this._box3)
//            this.oldemail = this._box3.getText();
    };
    this.editBoxTextChanged = function (editBox, text) {
        cc.log("editBox  TextChanged");
//        if (editBox == this._box2) this.check_m = 1;
//        if (editBox == this._box3) this.check_e = 1;
    };
    this.editBoxEditingDidEnd= function (editBox) {
        cc.log("editBox DidEnd !");
        if (editBox == this._box2)
        {
            if (this._box2.getText() == this.oldmobile)
                this.check_m = 0;
            else
                this.check_m = 1;
        }
        
        if (editBox == this._box3)
        {
            if (this._box3.getText() == this.oldemail)
                this.check_e = 0;
            else
                this.check_e = 1;
        }
        

            
    };
};

//================================================
//
//================================================
Member.prototype.onSetupPassword = function() {
    this.disablebox();
    this.SetupPasslayer.setVisible(true);
    this.SetupPasslayer.setZOrder(1);
    
    this._box5 = cc.EditBox.create(cc.size(240, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box5.setText("");
    this._box5.setInputFlag(cc.EDITBOX_INPUT_FLAG_PASSWORD);
    this._box5.setPosition(430, 650);
    this._box5.setFontColor(cc.c3b(251, 250, 0));
    this._box5.setMaxLength(12);
    this._box5.setDelegate(this);
    this._box5.setZOrder(0);
    this._box5.setTag(1);
    this.SetupPasslayer.addChild(this._box5);
    
    this._box6 = cc.EditBox.create(cc.size(240, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box6.setText("");
    this._box6.setInputFlag(cc.EDITBOX_INPUT_FLAG_PASSWORD);
    this._box6.setPosition(430, 564);
    this._box6.setFontColor(cc.c3b(251, 250, 0));
    this._box6.setMaxLength(12);
    this._box6.setDelegate(this);
    this._box6.setZOrder(0);
    this._box6.setTag(2);
    this.SetupPasslayer.addChild(this._box6);
};
//================================================
//
//================================================
Member.prototype.Setpass_cancle = function() {
    this.enablebox();
    this.SetupPasslayer.removeChildByTag(1);
    this.SetupPasslayer.removeChildByTag(2);
    this.SetupPasslayer.setVisible(false);
};

//================================================
//
//================================================
Member.prototype.Setpass_ok = function() {
    var oriPassword = this._box5.getText();
    var rePassword = this._box6.getText();
    if (oriPassword == rePassword)
    {
        cc.log("same password");
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function()
        {
            if (xhr.readyState==4)
            {// 4 = "loaded"
                if (xhr.status==200)
                {// 200 = "OK"
                    var response = JSON.parse(xhr.responseText);
                    if (response.result == 1)
                    {
                        cc.log("save password");
                        sys.localStorage.setItem('password',oriPassword);
                        this.ModifyPassword_Btn.setVisible(true);
                        this.SetupPassword_Btn.setVisible(false);
                        this.Setpass_cancle();
                    }
                }
            }
        }.bind(this);
        var urlcmd = "http://60.12.206.137/setuppassword.php?userid="+get_tuhaoid()+"&password="+oriPassword;
//        var urlcmd = "http://192.168.0.100/cdplatform/setuppassword.php?userid="+get_tuhaoid()+"&password="+oriPassword;
        cc.log(urlcmd);
        xhr.open("GET", urlcmd);
        xhr.send(null);

    }
    else
    {
        cc.log("Error!!");
    }
};

//================================================
//
//================================================
Member.prototype.onModifyPassword = function() {
    this.disablebox();
    this._box5 = cc.EditBox.create(cc.size(240, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box5.setText("");
    this._box5.setInputFlag(cc.EDITBOX_INPUT_FLAG_PASSWORD);
    this._box5.setPosition(430, 736);
    this._box5.setFontColor(cc.c3b(251, 250, 0));
    this._box5.setMaxLength(12);
    this._box5.setDelegate(this);
    this._box5.setZOrder(0);
    this._box5.setTag(1);
    this.ModifyPassLayer.addChild(this._box5);
    
    this._box6 = cc.EditBox.create(cc.size(240, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box6.setText("");
    this._box6.setInputFlag(cc.EDITBOX_INPUT_FLAG_PASSWORD);
    this._box6.setPosition(430, 650);
    this._box6.setFontColor(cc.c3b(251, 250, 0));
    this._box6.setMaxLength(12);
    this._box6.setDelegate(this);
    this._box6.setZOrder(0);
    this._box6.setTag(2);
    this.ModifyPassLayer.addChild(this._box6);
    
    this._box7 = cc.EditBox.create(cc.size(240, 50), cc.Scale9Sprite.create("ccbResources/ui_vip_data_bg.png"));
    this._box7.setText("");
    this._box7.setInputFlag(cc.EDITBOX_INPUT_FLAG_PASSWORD);
    this._box7.setPosition(430, 564);
    this._box7.setFontColor(cc.c3b(251, 250, 0));
    this._box7.setMaxLength(12);
    this._box7.setDelegate(this);
    this._box7.setZOrder(0);
    this._box7.setTag(3);
    this.ModifyPassLayer.addChild(this._box7);
    
    this.ModifyPassLayer.setZOrder(1);
    this.ModifyPassLayer.setVisible(true);
    
};
//================================================
//
//================================================
Member.prototype.ModifyPass_Cancle = function() {
    this.enablebox();
    this.ModifyPassLayer.removeChildByTag(1);
    this.ModifyPassLayer.removeChildByTag(2);
    this.ModifyPassLayer.removeChildByTag(3);
    this.ModifyPassLayer.setVisible(false);

}
//================================================
//
//================================================
Member.prototype.ModifyPass_ok = function() {
//    cc.log("ModifyPassword OK");
    var oldpassword = this._box5.getText();
    var newPassword = this._box6.getText();
    var rePassword = this._box7.getText();
    if ((oldpassword == null) || (newPassword == null) || (rePassword == null))
    {
        cc.log("need enter");
    }
    else
    {
        if (newPassword != rePassword)
        {
            cc.log("not same password");
        }
        else
        {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function()
            {
                if (xhr.readyState==4)
                {// 4 = "loaded"
                    if (xhr.status==200)
                    {// 200 = "OK"
                        var response = JSON.parse(xhr.responseText);
                        if (response.result == 1)
                        {
                            cc.log("save password");
                            sys.localStorage.setItem('password',oldpassword);
                            this.ModifyPassword_Btn.setVisible(true);
                            this.ModifyPass_Cancle();
                        }
                        else if (response.result == 2)
                        {
                            cc.log("old password error");
                        }
                        else if (response.result == 0)
                        {
                            cc.log("save error!");
                        }
                            
                    }
                }
            }.bind(this);
            var urlcmd = "http://60.12.206.137/modifypassword.php?userid="+get_tuhaoid()+"&oldpassword="+oldpassword+"&newpassword="+newPassword;
//            var urlcmd = "http://192.168.0.100/cdplatform/modifypassword.php?userid="+get_tuhaoid()+"&oldpassword="+oldpassword+"&newpassword="+newPassword;
            cc.log(urlcmd);
            xhr.open("GET", urlcmd);
            xhr.send(null);
        }
    }
}
//================================================
//
//================================================
Member.prototype.onChangeAccount = function() {
    this.ChangeAccountLayer.setZOrder(1);
};

Member.prototype.disablebox = function() {
    this._box1.setEnabled(false);
    this._box2.setEnabled(false);
    this._box3.setEnabled(false);
    this._box4.setEnabled(false);
};
Member.prototype.enablebox = function() {
    this._box1.setEnabled(true);
    this._box2.setEnabled(true);
    this._box3.setEnabled(true);
    this._box4.setEnabled(true);
}
//================================================
//
//================================================
Member.prototype.onCloseToFirst = function() {
    this.enablebox();
    this.MobileError.setVisible(false);
    this.EmailError.setVisible(false);
}
//================================================
//
//================================================
Member.prototype.onBack = function() {
    cc.log("go Back");
    var _nickname = this._box1.getText();
    var _mobile = this._box2.getText();
    var _email = this._box3.getText();
    var _QQ = this._box4.getText();
    
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function()
    {
        if (xhr.readyState==4)
        {// 4 = "loaded"
            if (xhr.status==200)
            {// 200 = "OK"
                cc.log(xhr.responseText);
                var response = JSON.parse(xhr.responseText);
                if (response.result == 1)     //成功
                {
                    cc.Director.getInstance().replaceScene(CCBMainMenu());
                }
                else if (response.result == 2) //电话被注册
                {
                    this.disablebox();
                    this.MobileError.setZOrder(1);
                    this.MobileError.setVisible(true);
                }
                else if (response.result == 3) //email被注册
                {
                    this.disablebox();
                    this.EmailError.setZOrder(1);
                    this.EmailError.setVisible(true);
                    
                }
                else if (response.result == 0) //更新失败
                {
                    cc.Director.getInstance().replaceScene(CCBMainMenu());
                }
            }
        }
    }.bind(this);
    if (_mobile == null)  _mobile = '';
    if (_email == null)  _email = '';
    if (_QQ == null)  _QQ = '';
    var urlcmd = "http://60.12.206.137/modifyinfo.php?userid="+get_tuhaoid()+"&nickname="+_nickname+"&mobile="+_mobile+"&email="+_email+"&QQnumber="+_QQ+"&check_e="+this.check_e+"&check_m="+this.check_m;
//    var urlcmd = "http://192.168.0.100/cdplatform/modifyinfo.php?userid="+get_tuhaoid()+"&nickname="+_nickname+"&mobile="+_mobile+"&email="+_email+"&QQnumber="+_QQ+"&check_e="+this.check_e+"&check_m="+this.check_m;
    cc.log(urlcmd);
    xhr.open("GET", urlcmd);
    xhr.send(null);


};
//================================================
//
//================================================
var CCBMember = function () {
    cc.log("CCBMember");
    var scene = cc.Scene.create();
    switch(language)
    {
        case 0:
            node = cc.BuilderReader.load("ccbi/Member_en.ccbi");
            break;
        case 12:
            node = cc.BuilderReader.load("ccbi/Member.ccbi");
            break;
        case 13:
            node = cc.BuilderReader.load("ccbi/Member_cht.ccbi");
            break;
        default:
            node = cc.BuilderReader.load("ccbi/Member.ccbi");
            break;
            
    }

    cc.log("loaded");

    scene.addChild(node);
    scene.setPosition(cc.p(0, 0));
    
    return scene;
};