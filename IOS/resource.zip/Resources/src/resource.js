var s_BGM   = "ccbResources/Sound/2048.mp3";
var s_Click = "ccbResources/Sound/click.mp3";
var s_move  = "ccbResources/Sound/move01.mp3";
var s_gameover  = "ccbResources/Sound/gameover.mp3";
var s_best  = "ccbResources/Sound/bestscore.mp3";

var s_Gamescene = "ccbi/GameScene_cht.ccbi";

var g_ressources = [
                    {type:'ccbi', src:"ccbi/Welcome.ccbi"},
                    {type:'ccbi', src:"ccbi/Help.ccbi"},
                    {type:'ccbi', src:"ccbi/Products.ccbi"},
                    {type:'ccbi', src:"ccbi/GameScene.ccbi"},
                    {type:'ccbi', src:"ccbi/member.ccbi"},
                    
//                    {type:'plist', src:"ccbResources/bird_frame.plist"},
//                    {type:'plist', src:"ccbResources/finger_frame.plist"},
//                    {type:'plist', src:"ccbResources/birdfly.plist"},
//                    {type:'plist', src:"ccbResources/birdfly.plist"},
                    
                    
//                    {type:'image', src:"ccbResources/number_2.png"},
//                    {type:'image', src:"ccbResources/number_1.png"},
//                    {type:'image', src:"ccbResources/welcome.png"},
                    
                    {type:'sound', src:s_BGM},
                    {type:'sound', src:s_Click},
                    {type:'sound', src:s_gameover},
                    {type:'sound', src:s_best},
                    {type:'sound', src:s_move}
];