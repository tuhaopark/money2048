//================================================
//
//================================================
var Ranklist = function(){
    cc.log("ranklist Func");
    this.RankArrayList = [];
    this.RanklistNode = this.RanklistNode || {};
    this.Jsonrespone = this.Jsonrespone ||{};
//    this.Btn_Score = this.Btn_Score || {};
//    this.Btn_2048 = this.Btn_2048 || {};
};
//================================================
//
//================================================
Ranklist.prototype.onDidLoadFromCCB = function () {
    cc.log("Ranklist loaded");
    
    
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function()
    {
        if (xhr.readyState==4)
        {
            // 4 = "loaded"
            if (xhr.status==200)
            {
                this.Jsonrespone = JSON.parse(xhr.responseText);
                this.onScore();
            }
            else {
                cc.log("Problem retrieving JSON data:" + xhr.statusText);
            }
        }
    }.bind(this);
    var urlcmd = "http://60.12.206.137/money2048/money2048rank.php?userid="+get_tuhaoid();
//    var urlcmd = "http://192.168.0.100/cdplatform/money2048/money2048rank.php?userid="+get_tuhaoid();
    xhr.open("GET", urlcmd, true);
    xhr.send(null);

}

//================================================
//
//================================================
Ranklist.prototype.onScore = function () {
    cc.log("onScore");
    this.Btn_Score.selected();
    this.Btn_2048.unselected();
    this.ClearScoreList(0);

    var totalrank = this.Jsonrespone.rankscoreList.length;
    for (var i = 0; i < totalrank; i++)
    {
        var node = this.RanklistNode.getChildByTag(100+i);
        var nickname = node.getChildByTag(1);
        nickname.setString(this.Jsonrespone.rankscoreList[i].nickname);
        var scorelabel = node.getChildByTag(2);
        scorelabel.setString(this.Jsonrespone.rankscoreList[i].score);
    }
    
    if (!this.Jsonrespone.mysocre)
        this.MyScoreLabel.setString(0);
    else
        this.MyScoreLabel.setString(this.Jsonrespone.mysocre.score);
}
//================================================
//
//================================================
Ranklist.prototype.on2048 = function () {
    cc.log("Btn_2048");
    this.Btn_Score.unselected();
    this.Btn_2048.selected();
    this.ClearScoreList(1);
    var totalrank = this.Jsonrespone.ranknumberList.length;
    for (var i = 0; i < totalrank; i++)
    {
        var node = this.RanklistNode.getChildByTag(100+i);
        var nickname = node.getChildByTag(1);
        nickname.setString(this.Jsonrespone.ranknumberList[i].nickname);
        var scorelabel = node.getChildByTag(2);
        scorelabel.setString(this.Jsonrespone.ranknumberList[i].high_number);
        var timelabel = node.getChildByTag(3);
        timelabel.setString(getTotalTime(this.Jsonrespone.ranknumberList[i].playtime));
    }
    if (!this.Jsonrespone.myhighnum)
        this.MyScoreLabel.setString(0+"         00:00:00");
    else
        this.MyScoreLabel.setString(this.Jsonrespone.myhighnum.high_number+"  "+getTotalTime(this.Jsonrespone.myhighnum.playtime));
}

//================================================
//
//================================================
Ranklist.prototype.newitem = function (num, mode) {
    var winsize =  cc.Director.getInstance().getWinSize();
    var ccSpriteBg = cc.Sprite.createWithSpriteFrameName("rank_list_bg.png");
    ccSpriteBg.setPosition(cc.p(322, 724-num*50));
    ccSpriteBg.setTag(100+num);
    this.RanklistNode.addChild(ccSpriteBg);
    var ranklabel = cc.LabelTTF.create(num+1, "ArialMT", 20);
    ranklabel.setPosition(cc.p(10,20));
    ranklabel.setColor(cc.black());
    ccSpriteBg.addChild(ranklabel);
    
    var nicknamelabel = cc.LabelTTF.create("Guest", "ArialMT", 26);
    nicknamelabel.setPosition(cc.p(140,38));
    nicknamelabel.setAnchorPoint(cc.p(0, 1));
    nicknamelabel.setColor(cc.black());
    nicknamelabel.setTag(1);
    ccSpriteBg.addChild(nicknamelabel);
    
    if (mode == 0)
    {
        var socrelabel = cc.LabelTTF.create("0", "ArialMT", 26);
        socrelabel.setPosition(cc.p(386,38));
        socrelabel.setAnchorPoint(cc.p(0, 1));
        socrelabel.setColor(cc.black());
        socrelabel.setTag(2);
        ccSpriteBg.addChild(socrelabel);
    }
    else
    {
        var socrelabel = cc.LabelTTF.create("0000", "ArialMT", 26);
        socrelabel.setPosition(cc.p(386,38));
        socrelabel.setAnchorPoint(cc.p(0, 1));
        socrelabel.setColor(cc.black());
        socrelabel.setTag(2);
        ccSpriteBg.addChild(socrelabel);
        
        var timelabel = cc.LabelTTF.create("00:00:00", "ArialMT", 26);
        timelabel.setPosition(cc.p(466,38));
        timelabel.setAnchorPoint(cc.p(0, 1));
        timelabel.setColor(cc.black());
        timelabel.setTag(3);
        ccSpriteBg.addChild(timelabel);
        
    }
//    var testlabel = cc.LabelTTF.create("测试中文", "Microsoft Yahei", 36);
//    testlabel.setPosition(cc.p(100,200));
//    testlabel.setColor(cc.black());
//    this.RanklistNode.addChild(testlabel);
}
//================================================
//
//================================================
Ranklist.prototype.ClearScoreList = function(mode) {
    for (var i = 0; i < 15; i++)
        this.RanklistNode.removeChildByTag(100+i);
    
    for (var i = 0; i < 15; i++)
        this.newitem(i, mode);
};
//================================================
//
//================================================
Ranklist.prototype.onBack = function() {
    cc.log("go Back");
    cc.Director.getInstance().replaceScene(CCBMainMenu());
};

//================================================
//
//================================================
var CCBRanklist = function () {
    cc.log("CCBRanklist");
    var scene = cc.Scene.create();
    switch(language)
    {
        case 0:
            node = cc.BuilderReader.load("ccbi/Ranklist_en.ccbi");
            break;
        case 12:
            node = cc.BuilderReader.load("ccbi/Ranklist.ccbi");
            break;
        case 13:
            node = cc.BuilderReader.load("ccbi/Ranklist_cht.ccbi");
            break;
        default:
            node = cc.BuilderReader.load("ccbi/Ranklist.ccbi");
            break;
            
    }
    
    
    scene.addChild(node);
    scene.setPosition(cc.p(0, 0));
    
    return scene;
};