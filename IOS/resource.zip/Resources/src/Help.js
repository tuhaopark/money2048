//================================================
//
//================================================
var Help = function(){
    cc.log("Help Func");
    this.Page1 = this.Page1 || {};
    this.Page2 = this.Page2 || {};
    this.Page3 = this.Page3 || {};
    this.Page4 = this.Page4 || {};
    this.Page5 = this.Page5 || {};
};

//================================================
//
//================================================
Help.prototype.onGoPage2 = function() {
    cc.log("goPage2");
    audioEngine.playEffect(s_Click);
    this.Page1.setVisible(false);
    this.Page2.setVisible(true);
    
}
//================================================
//
//================================================
Help.prototype.onGoPage3 = function() {
    cc.log("goPage3");
    audioEngine.playEffect(s_Click);
    this.Page2.setVisible(false);
    this.Page3.setVisible(true);
    
}
//================================================
//
//================================================
Help.prototype.onGoPage4 = function() {
    cc.log("goPage4");
    audioEngine.playEffect(s_Click);
    this.Page3.setVisible(false);
    this.Page4.setVisible(true);
    
}
//================================================
//
//================================================
Help.prototype.onGoPage5 = function() {
    cc.log("goPage5");
    audioEngine.playEffect(s_Click);
    this.Page4.setVisible(false);
    this.Page5.setVisible(true);
    
}

//================================================
//
//================================================
Help.prototype.onStartGame = function() {
    cc.log("goStartGame");
    audioEngine.playEffect(s_Click);
    this.Page4.setVisible(false);
    cc.Director.getInstance().replaceScene(CCBPlayGame());
}

//================================================
//
//================================================
var CCBHelp = function () {
    cc.log("CCBHelp");
    var scene = cc.Scene.create();
    switch(language)
    {
//        case 0:
//            node = cc.BuilderReader.load("ccbi/Help_en.ccbi");
//            break;
//        case 12:
//            node = cc.BuilderReader.load("ccbi/Help.ccbi");
//            break;
//        case 13:
//            node = cc.BuilderReader.load("ccbi/Help_cht.ccbi");
//            break;
        default:
            node = cc.BuilderReader.load("ccbi/Help.ccbi");
            break;
            
    }
    
//    node = cc.BuilderReader.load("ccbi/Help.ccbi");
    
    scene.addChild(node);
    scene.setPosition(cc.p(0, 0));
    
    return scene;
};